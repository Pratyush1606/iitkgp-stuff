package com.example.app_accelerometer;

import android.app.Activity;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import android.os.Environment;
import java.io.*;
import java.lang.Math;

///////////////  Main-Activity///////////////////////////

public class MainActivity extends Activity implements SensorEventListener {
    private TextView xText,yText,zText,text;
    private Sensor mySensor;
    private SensorManager SM;
    private Boolean flag=false;
    private static final KalmanFilter1 KF=new KalmanFilter1();
    private static final MatFunc MATLAB =new MatFunc();
    String fileName="sensordata.txt";
    String baseDir = Environment.getExternalStorageDirectory().getAbsolutePath();
    String pathDir = baseDir + "/Android/data/com.mypackage.app_accelerometer/";
    File file;

    File gpxfile;
    FileWriter writer;
    private OutputStreamWriter outputWriter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//        initializeViews();
        SM=(SensorManager) getSystemService(Context.SENSOR_SERVICE);
        mySensor=SM.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        SM.registerListener( this,mySensor,SensorManager.SENSOR_DELAY_NORMAL);
        xText=(TextView) findViewById(R.id.xText);
        yText=(TextView) findViewById(R.id.yText);
        zText=(TextView) findViewById(R.id.zText);
        text=(TextView) findViewById(R.id.text);
        file=new File(MainActivity.this.getFilesDir(),"Kalman");
        if (!file.exists()) {
            file.mkdir();
        }
    }
//    @Override
    public void onStartClick(View view) {
            flag=true;

        try {
            text.setText("starting writing data");
            gpxfile=new File(file,"sensordata.txt");
            writer=new FileWriter(gpxfile);
//            FileOutputStream fileout=openFileOutput(,MODE_PRIVATE);
//            outputWriter=new OutputStreamWriter(fileout);
            KF.init();

        } catch(Exception e){

            text.setText(e.getMessage());
            e.printStackTrace();
        }
    }
//    @Override
    public void onStopClick(View view) {
        flag=false;

        try {

//            outputWriter.close();
            writer.close();
            text.setText("Stopped writting data!");
            Toast.makeText(MainActivity.this,"File saved successfully!",
            Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            text.setText(e.getMessage());
            e.printStackTrace();
        }
    }
//    protected void onResume() {
//        super.onResume();
//
//    }
    @Override
    public void onSensorChanged(SensorEvent event) {



        double[][] Z=new double[3][1];
        for (int i=0; i<3; i++) {
            Z[i][0] = event.values[i];
        }
        double[][] zcap = KF.track(Z, System.currentTimeMillis()/1e3);

        xText.setText("X: " + Z[0][0]+"->X_new: "+zcap[0][0]);
        yText.setText("Y: " + Z[1][0]+"->Y_new: "+zcap[1][0]);
        zText.setText("Z: " + Z[2][0]+"->Z_new: "+zcap[2][0]);
        if (flag) {
            String str = (Z[0][0] + "," + Z[1][0] + "," + Z[2][0] + "\t\t\t" + zcap[0][0]+','+zcap[1][0]+','+zcap[2][0]+'\n');

        try {
//            outputWriter.write(str);
            writer.append(str);
            writer.flush();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    }

    @Override
    public void onAccuracyChanged(Sensor sensor,int accuracy){

    }

}

