package com.example.app_accelerometer;
import android.content.Context;
import android.widget.Toast;
import java.lang.Math;
///////////////////////Kalman Flter/////////////////////////////
public class KalmanFilter1 {


    private static  final MatFunc MATLAB = new MatFunc();
    public static  final double[][] H = new double[][]{  {0, 0, 0, 0, 0, 0, 1, 0, 0},
            {0, 0, 0, 0, 0, 0, 0, 1, 0},
            {0, 0, 0, 0, 0, 0, 0, 0, 1}};

    public static double[][] P = new double[9][9];
    public static double[][] R = new double[3][3];
    public static double[][] Q = new double[9][9];
    public static double[][] X = new double[9][1];
    public static double[][] K = new double[9][3];
    public double prevTime = 0.0;
    public static double h;


    public void init() {
        prevTime = System.currentTimeMillis() / 1e3;

        for (int i = 0; i < 9; i++) {
            for (int j = 0; j < 3; j++) {
                K[i][j] = 0;
            }
        }
        for (int i = 0; i < 9; i++) {
            X[i][0] = 0.1;

            for (int j = 0; j < 9; j++) {
                if (i == j) {
//                    P[i][j] = 5;
//                    Q[i][j] = 1;
                    P[i][j] = 1;
                    Q[i][j] = 0.0001;
                } else {
                    P[i][j] = 0;
                    Q[i][j] = 0;
                }
            }
        }
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (i == j) {
//                    R[i][j] = 0.1;
                    R[i][j] = 0.01;
                } else

                    R[i][j] = 0;
            }
        }
    }


    public double[][] track(double[][] Z, double time) {

        // Implements the Kalman Filter
        // dX = Ph*X + q
        // z = H*X + r
        // Q = Cov(q), R = Cov(r)
        h = time - prevTime;
        prevTime = time;
        double h2 = (h*h)/2;
        double[][] Ph = new double[][]{ {1, 0, 0, h, 0, 0, h2, 0, 0},
                {0, 1, 0, 0, h, 0, 0, h2, 0},
                {0, 0, 1, 0, 0, h, 0, 0, h2},
                {0, 0, 0, 1, 0, 0, h, 0, 0},
                {0, 0, 0, 0, 1, 0, 0, h, 0},
                {0, 0, 0, 0, 0, 1, 0, 0, h},
                {0, 0, 0, 0, 0, 0, 1, 0, 0},
                {0, 0, 0, 0, 0, 0, 0, 1, 0},
                {0, 0, 0, 0, 0, 0, 0, 0, 1}};
        // Step 1 : Compute Kalman Gain
        // K = P*H*(H*P*H' + R)^-1
        double[][] Ht = MATLAB.matTranspose(H, 3, 9);
        double[][] Ktemp = MATLAB.matMul(H, P, 3, 9, 9);
        Ktemp = MATLAB.matMul(Ktemp, Ht, 3, 9, 3);
        Ktemp = MATLAB.matAdd(Ktemp, R, 3, 3, 1);
        double[][] inv = new double[3][3];
         boolean invertible = MATLAB.inverse(Ktemp, inv, 3);
        if (invertible) {
            Ktemp = MATLAB.matMul(P, Ht, 9, 9, 3);
            Ktemp = MATLAB.matMul(Ktemp, inv, 9, 3, 3);
            for (int i=0; i<9; i++) {
                for (int j=0; j<3; j++) {
                    K[i][j] = Ktemp[i][j];
                }
            }
        }
        // Step 2 : Update the estimates
        // zcap = H*x
        // x = x + K*(z - zcap)
        double[][] zcap = MATLAB.matMul(H, X, 3, 9, 1);
        X = MATLAB.matAdd(X, MATLAB.matMul(K, MATLAB.matAdd(Z, zcap, 3, 1, -1), 9, 3, 1), 9, 1, 1);

        // Step 3 : Compute posterior error covariance
        // P = (I - K*H)*P
        P = MATLAB.matMul(MATLAB.matAdd(MATLAB.genID(9), MATLAB.matMul(K, H, 9, 3, 9), 9, 9, -1), P, 9, 9, 9);
        // Save the value
        double[][] zret=new double [3][1];
        zret[0][0]=X[6][0];
        zret[1][0]=X[7][0];
        zret[2][0]=X[8][0];
        // Step 4 : Project ahead
        // x = Ph*x
        // P = Ph*P*Ph' + Q
        X = MATLAB.matMul(Ph, X, 9, 9, 1);
        P = MATLAB.matMul(MATLAB.matMul(Ph, P, 9, 9, 9), MATLAB.matTranspose(Ph, 9, 9), 9, 9, 9);
        P = MATLAB.matAdd(P, Q, 9, 9, 1);
        return zcap;

//        return zret;
    }


}
